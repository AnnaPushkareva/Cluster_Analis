//211-Pushkareva-Anna-2021
#include "Interface.h"
int main()
{
	Interface Interfase;
	Interfase.Command();
	return 0;

}
