//211-Pushkareva-Anna-2021
#pragma once
#include "Point.h"
#include "Dist_Matrix.h"
class Algoritm_S_Tree
{
public:
    void Start(vector <int>& STree, vector <Point>& All_Point, Dist_Matrix& D);
};

