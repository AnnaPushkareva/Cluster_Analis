//211-Pushkareva-Anna-2021
#include "Triang_Delon.h"
