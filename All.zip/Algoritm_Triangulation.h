//211-Pushkareva-Anna-2021
#pragma once
#include "Point.h"
#include "Triang_Delon.h"
class Algoritm_Triangulation
{
public:
	Triang_Delon Start(vector <Point>& All_Point);
};

